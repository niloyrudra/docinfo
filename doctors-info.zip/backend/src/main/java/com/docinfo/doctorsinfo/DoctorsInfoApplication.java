package com.docinfo.doctorsinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorsInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorsInfoApplication.class, args);
	}

}
