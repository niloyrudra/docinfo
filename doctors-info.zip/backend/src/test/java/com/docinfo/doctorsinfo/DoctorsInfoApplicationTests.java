package com.docinfo.doctorsinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorsInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
